package com.tuempresa.aprendeapp.utils

object Constants {
    const val EXTRA_RECURSO = "extra_recurso"
    const val EXTRA_IS_EDIT = "extra_is_edit"
}