package com.tuempresa.aprendeapp.data.model

data class RecursosResponse(
    val recursos: List<Recurso>
)